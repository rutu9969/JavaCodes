package com.capgemini.testcode;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.test.bean.AccountHolder;
import com.capgemini.test.dao.DaoClass ;
import com.capgemini.test.exception.RecordNotFoundException;



	public class testClass {
		DaoClass obj=null;
		@Before
		public void beforeMethod() throws Exception{
			obj=new DaoClass();
		}
		@After
		public void afterMethod() throws Exception{
			obj=null;
		}
		@Test
		public void testValidateCustomer() throws RecordNotFoundException{
			AccountHolder holder1=new AccountHolder();
			AccountHolder reqCustomer=new AccountHolder();
			holder1.setHolderName("Rutuja");
			holder1.setHolderAddress("Pune");
		
		
			obj.storeIntoMap(holder1);
			
			int id= holder1.getAccountNumber();
			reqCustomer =obj.find(id);
			Assert.assertNotNull(reqCustomer);
			System.out.println("test passed");
			
			
		}
		@Test
		public void testInValidateCustomer() throws RecordNotFoundException{
			AccountHolder holder1=new AccountHolder();
			AccountHolder reqCustomer=new AccountHolder();
			holder1.setHolderName("Rutuja");
			holder1.setHolderAddress("Pune");
		
		
			obj.storeIntoMap(holder1);
			
			int id= holder1.getAccountNumber();
			reqCustomer =obj.find(10);
			Assert.assertNotNull(reqCustomer);
			System.out.println("test passed");
			
		}

	}



