package com.capgemini.test.bean;

public class Transaction {
	  protected String type;
	   protected double amount,balance;
   public Transaction()
	   {}
	public Transaction(String type, double amount, double balance) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}
	   @Override
	public String toString() {
		return super.toString();
	}
	   public String print()
   {
		   return type+"\t"+amount +"\t"+balance;
	   }

}
