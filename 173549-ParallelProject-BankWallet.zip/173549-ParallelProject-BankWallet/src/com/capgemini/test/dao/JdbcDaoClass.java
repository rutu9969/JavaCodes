package com.capgemini.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cagemini.test.utility.JdbcUtility;
import com.capgemini.test.bean.AccountHolder;
import com.capgemini.test.exception.RecordNotFoundException;

public class JdbcDaoClass implements DaoInterface{
	
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	
	@Override
	public void insertCustomerDetail(AccountHolder holder)
			throws RecordNotFoundException {
		connection = JdbcUtility.getConnection();

		try {
			statement = connection.prepareStatement(QuerryMapper.insertDetails);

			statement.setInt(1, holder.getAccountNumber());
			statement.setString(2, holder.getHolderName());
			statement.setString(3,holder.getHolderAddress());
			statement.setString(4,holder.getHolderMobile());
			statement.setDouble(5, holder.getAccountBalance());

			statement.executeUpdate();

		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);

		} finally {

			try {
				statement.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close statement object");
			}

			try {
				connection.close();
			} catch (SQLException e) {

				throw new RecordNotFoundException(
						"unable to close connection object");
			}
		}

	}


	

	@Override
	public void storeIntoMap(AccountHolder holder) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double showBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fundTransfer(double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
		
	}

	

}
