package com.capgemini.test.dao;

public interface QuerryMapper {

	 String insertDetails =
			"insert into AccountHolder"
			+ "(accountNumber,holderName,holderAddress,holderMobile,accountBalance)"+"Values"
			+ "(?,?,?,?,?)";
			
	
	String sql =
			"select * from AccountHolder where AccountNumber=?";

}

